<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'hito' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '123' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '<;>X{5jHH>MhtM~&JwlAN:Hhr15/2<v9q5^Q=`G7xi|[KF~q,ya`-$ph|w+bt@B6' );
define( 'SECURE_AUTH_KEY',  '&-IAvm^&<x|-@pYc|]9W;uh:L|,ZdK)r6ZPSHG2w[XBDIlR)<1V8#aVCU Vg%& `' );
define( 'LOGGED_IN_KEY',    '_LzaXzX)Ohf!Y&~G1fPf/X3^G7u0$9NFlB7Hq C}l!||w*nteD+>y}MIVJo]`=</' );
define( 'NONCE_KEY',        'ge`#rjBy0_I0 ,Zl`CPjZCNFVh|+w1Zr3X6dJl^s4`q$8mPi9IsBb8iYXk_i+I)F' );
define( 'AUTH_SALT',        'px]F8%;%jX61mvcc&&XUSx%dl`k,[|.tfW-e^$DWA%_>Y8U[O;.I0uk2<>CSkzX5' );
define( 'SECURE_AUTH_SALT', 'K_]V8mnAP_kde{=(([B6Z@Hzg6-6w/#L5!E f.tiBc }glc>a4+BKDiG6.uF<^)H' );
define( 'LOGGED_IN_SALT',   'gQ+[@5U5Hhq;-^gLzjZ!|fbKRL#~`qjsmmzf;{U]m,4[k#]{0E7|ZlUuC6&boP~4' );
define( 'NONCE_SALT',       '{Hr%~eL2ieO wB_:Y,W.6<DZ2f[m0+>tD9)!kIRCN#kQN72Q>D^YsZC8k@JCL|zm' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
